﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace FarmSystem
{
    public class EmydexFarmSystem
    {
        public static List<Animal> animals = new List<Animal>();

        //TEST 1
        public void Enter(Animal animal)
        {
            animals.Add(animal);
            DisplayAnimalType(animal);
        }

        //TEST 2
        public void MakeNoise()
        {
            animals.ForEach(animal =>
            {
                animal.Talk();
            });
        }

        //TEST 3
        public void MilkAnimals()
        {
            var milkableAnimals = animals.Where(animal => animal is IMilkableAnimal).ToList();
            milkableAnimals.ForEach(milkableAnimal =>
            {
                ((IMilkableAnimal)milkableAnimal).ProduceMilk();
            });

        }

        //TEST 4
        public void ReleaseAllAnimals()
        {
            var typeofRemovedAnimals = animals.Select(animal => animal.GetType().Name).ToList();
            animals.Clear();
            typeofRemovedAnimals.ForEach(typeofRemovedAnimal =>
            {
                Console.WriteLine($"{typeofRemovedAnimal} has left the farm");
            });
            typeofRemovedAnimals.Clear();
        }
        public void DisplayAllAnimalTypes()
        {
            if (animals.Count > 0)
            {
                animals.ForEach(animal =>
                {
                    DisplayAnimalType(animal);
                });
            }
            else
            {
                Console.WriteLine("There are no animals in the farm");
            }
        }

        private static void DisplayAnimalType(Animal animal)
        {
            var animalType = animal.GetType().Name;
            Console.WriteLine($"{animalType} has entered the farm");
        }

        // declare a delegate function
        public delegate void Notify (List<Animal> animals);

        public event Notify OnFarmEmpty;

        public void FarmEmpty()
        {
            OnFarmEmpty?.Invoke(animals);
        }
      
    }

}