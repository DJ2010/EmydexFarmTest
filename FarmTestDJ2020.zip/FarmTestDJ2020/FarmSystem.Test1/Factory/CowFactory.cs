﻿namespace FarmSystem
{
    class CowFactory : IAnimalFactory
    {
        public Animal CreateAnimal()
        {
            return new Cow();
        }
    }
}
