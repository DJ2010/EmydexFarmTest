﻿namespace FarmSystem
{
    class HenFactory : IAnimalFactory
    {
        public Animal CreateAnimal()
        {
            return new Hen();
        }
    }
}
