﻿namespace FarmSystem
{
    class HorseFactory : IAnimalFactory
    {
        public Animal CreateAnimal()
        {
            return new Horse();
        }
    }
}
