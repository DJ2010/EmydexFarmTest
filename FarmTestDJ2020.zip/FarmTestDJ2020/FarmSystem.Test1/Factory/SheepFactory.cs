﻿namespace FarmSystem
{
    class SheepFactory : IAnimalFactory
    {
        public Animal CreateAnimal()
        {
            return new Sheep();
        }
    }
}
