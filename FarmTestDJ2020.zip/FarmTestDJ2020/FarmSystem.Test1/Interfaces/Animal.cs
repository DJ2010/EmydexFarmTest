﻿namespace FarmSystem
{
    /// <summary>
    ///  Provides an abstract base class for all animals
    /// </summary>
    public abstract class Animal
    {
        private string _id;
        private int _noOfLegs = 4;

        public string Id
        {
            get { return _id; }
            set
            {
                _id = value;
            }
        }

        public int NoOfLegs
        {
            get
            {
                return _noOfLegs;
            }
            set
            {
                _noOfLegs = value;
            }
        }

        #region  Public Methods

        public abstract void Talk();
        public abstract void Run();

        #endregion
    }
}
