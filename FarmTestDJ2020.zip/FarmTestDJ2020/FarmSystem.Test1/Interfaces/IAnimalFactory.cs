﻿namespace FarmSystem
{
    /// <summary>
    /// Interface which exposes method to create animals
    /// </summary>
    public interface IAnimalFactory
    {
         Animal CreateAnimal();
    }
}
