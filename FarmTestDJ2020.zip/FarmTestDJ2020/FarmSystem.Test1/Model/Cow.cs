﻿using System;

namespace FarmSystem
{
    public class Cow : Animal, IMilkableAnimal 
    {
        public Cow()
        {
            Id = Guid.NewGuid().ToString(); 
        }
        public override void Talk()
        {
            Console.WriteLine("Cow says Moo!");
        }
        public override void Run()
        {
            Console.WriteLine("Cow is running");
        }

        public void Walk()
        {
            Console.WriteLine("Cow is walking");
        }

        public void ProduceMilk()
        {
            Console.WriteLine("Cow produced milk");
        }

    }
}