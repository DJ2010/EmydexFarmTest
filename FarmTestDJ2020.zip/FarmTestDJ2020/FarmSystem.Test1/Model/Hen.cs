﻿using System;

namespace FarmSystem
{
    public class Hen : Animal
    {
        public Hen()
        {
            NoOfLegs = 2;
            Id = Guid.NewGuid().ToString();
        }
        public override void Talk()
        {

            Console.WriteLine("Hen say CLUCKAAAAAWWWWK!");
        }

        public override void Run()
        {
            Console.WriteLine("Hen is running");
        }
    }
}