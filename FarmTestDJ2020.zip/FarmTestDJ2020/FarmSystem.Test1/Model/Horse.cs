﻿using System;

namespace FarmSystem
{
    public class Horse : Animal
    {
        public Horse()
        {
            Id = Guid.NewGuid().ToString();
        }
        public override void Talk()
        {
            Console.WriteLine("Horse says neigh!");
        }

        public override void Run()
        {
            Console.WriteLine("Horse is running");
        }
        
    }
}