﻿using System;

namespace FarmSystem
{
    public class Sheep : Animal, IMilkableAnimal
    {
        public Sheep()
        {
            Id = Guid.NewGuid().ToString();
        }
        public override void Talk()
        {
            Console.WriteLine("Sheep says baa!");
        }
        
        public override void Run()
        {
            Console.WriteLine("Sheep is running");
        }

        public void ProduceMilk()
        {
            Console.WriteLine("Sheep produced milk");
        }
    }

}